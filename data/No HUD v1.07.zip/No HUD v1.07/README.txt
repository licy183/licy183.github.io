Created by: Kuroha Saenoki (TheDarkenedOne)
https://www.youtube.com/user/ItachiTheDarkenedOne

Install:

1. Go to root of your game
( Steam\steamapps\common\NARUTO SHIPPUDEN Ultimate Ninja STORM 4 )

2. Drag "data" from the "No HUD" folder into your root

3. Overwrite all files that come up

4. Start Game

*NOTE "Command Pop-Up display" & "Display Jutsu Name" still functions as normal, 
disable them yourself in free battle (ingame).

*NOTE2: "Subtitles" still functions as normal, 
disable them yourself in the options menu (in the game mode selection).

Uninstall:

1. Go to the root of your game

2. Drag "data" from the "HUD Restore" folder into your root

3. Overwrite all files that come up

4. Start game & see if it worked 
IF for some reason it didn't, Go to next step

5. Go onto Steam Library, Right Click on NARUTO SHIPPUDEN Ultimate Ninja STORM 4

6. Go into the Local Files tab & click on "Verify Intergity of Game Cache..."

7. A pop-up scan all your files & will fix all your modded files.
(this will NOT remove your data_win32)